pimaData = csvread('pima.data');

[fold1, fold2, fold3, fold4, fold5, fold6, fold7, fold8, fold9, fold10] = extractFolds(pimaData);

for k = 1:2:15
    acc = crossFoldValidation(pimaData, k, 0, 0);
    fprintf('Average accuracy across all folds for k = %d is %.4f\n', k, acc);
end

acc5 = crossFoldValidation(pimaData, 0, 1, 0.5);
fprintf('Average accuracy across all folders for weighted-KNN with sigma = 0.5 is %.4f\n', acc5);

acc2 = crossFoldValidation(pimaData, 0, 1, 0.2);
fprintf('Average accuracy across all folders for weighted-KNN with sigma = 0.2 is %.4f\n', acc2);

acc01 = crossFoldValidation(pimaData, 0, 1, 0.01);
fprintf('Average accuracy across all folders for weighted-KNN with sigma = 0.01 is %.4f\n', acc01);

function cumAcc = crossFoldValidation(data, k, algorithm, sigma)
    cumAcc = 0.0;
    for i = 1:10
        test = data(i*76-75 : i*76, :);
        train = extractTrain(data, i);
        [testX, testY] = splitXy(test);
        [trainX, trainY] = splitXy(train);
        
        [means, stds] = computeMeanStd(trainX);
        trainX = normalizeData(trainX, means, stds);
        testX = normalizeData(testX, means, stds);
        
        %pred = zeros(size(testX, 1));
        if algorithm == 0 % regular, non-weighted KNN
            pred = my_knn(trainX, trainY, testX, k);
        else % weighted KNN
            pred = weighted_knn(trainX, trainY, testX, sigma);
        end
        acc = computeAccuracy(testY, pred);
        cumAcc = cumAcc + acc;
    end
    cumAcc = cumAcc / 10.0;
end

function acc = computeAccuracy(testY, predY)
    correct = 0;
    N = size(testY, 1);
    for i = 1:N
        if testY(i) == predY(i)
            correct = correct + 1;
        end
    end
    
    acc = correct / N;
end

function train = extractTrain(data, i)
    beginTestIndex = i*76-75;
    endTestIndex = i*76;
    if beginTestIndex == 1
        train = data(endTestIndex+1 : end, :);
    elseif beginTestIndex == 760-75
        train = data(1:beginTestIndex-1, :);
    else
        train = data(1:beginTestIndex-1, :);
        train = [train; data(endTestIndex+1 : end, :)];
    end
end

function [X, y] = splitXy(data)
    D = size(data, 2);
    X = data(:, 1:D-1);
    y = data(:, D);
end

function newData = normalizeData(data, means, stds)
    N = size(data, 1);
    D = size(means, 1);
    newData = zeros(N, D);
    for i = 1:D
        newCol = (data(:, i) - means(i)) / stds(i);
        newData(:, i) = newCol;
    end
end

% Calculate the mean and std of each feature, or column, of the data
function [means, stds] = computeMeanStd(trainData)
    D = size(trainData, 2);
    means = zeros(D, 1);
    stds = zeros(D, 1);
    for i = 1:D
        means(i) = mean(trainData(:, i));
        stds(i) = std(trainData(:, i));
    end
end

function [fold1, fold2, fold3, fold4, fold5, fold6, fold7, fold8, fold9, fold10] = extractFolds(data)
    fold1 = data(1:76);
    fold2 = data(77:152);
    fold3 = data(153:228);
    fold4 = data(229:304);
    fold5 = data(305:380);
    fold6 = data(381:456);
    fold7 = data(457:532);
    fold8 = data(533:608);
    fold9 = data(609:684);
    fold10 = data(685:760);
end